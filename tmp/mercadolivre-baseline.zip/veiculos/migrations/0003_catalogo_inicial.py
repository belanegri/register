from django.db import migrations

"""Lista inicial fornecida pela PontoCar; os cadastros ficam no banco."""

CATALOGO = {
    "Chevrolet": "Agile, Astra, Blazer, Celta, Chevette, Classic, Cobalt, Corsa, Cruze, Kadett, Meriva, Montana, Monza, Ômega, Onix, Onix Plus, Opala, Prisma, S10, Spin, Tracker, Trailblazer, Vectra, Zafira",
    "Fiat": "147, Argo, Bravo, Cronos, Doblo, Fastback, Fiorino, Grand Siena, Idea, Linea, Marea, Mobi, Palio, Pulse, Punto, Siena, Stilo, Strada, Tempra, Tipo, Toro, Uno",
    "Ford": "Belina, Bronco, Corcel, Courier, EcoSport, Edge, Escort, Fiesta, Focus, Fusion, Ka, Maverick, Mondeo, Mustang, Pampa, Ranger, Territory, Verona",
    "Volkswagen": "Amarok, Bora, Brasília, CrossFox, Fox, Fusca, Gol, Golf, Jetta, Kombi, Logus, Nivus, Parati, Passat, Polo, Santana, Saveiro, SpaceFox, T-Cross, Taos, Tera, Tiguan, Up!, Variant, Virtus, Voyage",
    "Renault": "Captur, Clio, Duster, Fluence, Kardian, Kwid, Logan, Master, Megane, Oroch, Sandero, Scenic, Stepway, Symbol",
    "Peugeot": "106, 206, 207, 208, 2008, 306, 307, 308, 3008, 408, 508, Partner",
    "Citroën": "Aircross, Basalt, Berlingo, C3, C3 Aircross, C4, C4 Cactus, C4 Lounge, C5, C5 Aircross, Xsara, Xsara Picasso",
    "Toyota": "Bandeirante, Camry, Corolla, Corolla Cross, Etios, Fielder, Hilux, Prius, RAV4, SW4, Yaris, Yaris Cross",
    "Honda": "Accord, City, Civic, CR-V, Fit, HR-V, WR-V, ZR-V",
    "Hyundai": "Azera, Creta, Elantra, HB20, HB20S, i30, ix35, Santa Fe, Sonata, Tucson, Veloster, Veracruz",
    "Nissan": "Frontier, Grand Livina, Kicks, Livina, March, Pathfinder, Sentra, Tiida, Versa, X-Trail",
    "Jeep": "Cherokee, Commander, Compass, Grand Cherokee, Renegade, Wrangler",
    "Mitsubishi": "ASX, Eclipse Cross, L200, Lancer, Outlander, Pajero, Pajero Sport, Pajero TR4",
    "Kia": "Bongo, Carnival, Cerato, Magentis, Mohave, Picanto, Sorento, Soul, Sportage",
    "CAOA Chery": "Arrizo 5, Arrizo 6, Celer, Cielo, Face, QQ, Tiggo 2, Tiggo 3X, Tiggo 5X, Tiggo 7, Tiggo 8",
    "BYD": "Dolphin, Dolphin Mini, Han, King, Seal, Song Plus, Song Pro, Tan, Yuan Plus, Yuan Pro",
    "GWM": "Haval H6, Haval H9, Ora 03, Poer",
    "BMW": "Série 1, Série 2, Série 3, Série 4, Série 5, Série 7, X1, X2, X3, X4, X5, X6, X7",
    "Mercedes-Benz": "Classe A, Classe B, Classe C, Classe E, Classe S, CLA, GLA, GLB, GLC, GLE, GLS",
    "Audi": "A1, A3, A4, A5, A6, A7, A8, Q3, Q5, Q7, Q8, TT",
    "Volvo": "C30, S40, S60, S80, V40, V60, XC40, XC60, XC90",
    "Suzuki": "Grand Vitara, Jimny, S-Cross, Swift, SX4, Vitara",
    "Subaru": "Forester, Impreza, Legacy, Outback, WRX, XV",
    "Land Rover": "Defender, Discovery, Discovery Sport, Freelander, Range Rover, Range Rover Evoque, Range Rover Sport, Range Rover Velar",
    "Porsche": "718, 911, Cayenne, Macan, Panamera",
    "RAM": "1500, 2500, 3500, Rampage",
    "JAC": "J2, J3, J5, J6, T40, T50, T60",
    "Geely": "EX2, GC2, EC7",
    "GAC": "Aion, GS3, GS4",
    "Omoda": "Omoda 5, Omoda 7",
    "Jaecoo": "Jaecoo 7",
    "Mini": "Cooper, Countryman, Clubman",
    "Dodge": "Dakota, Durango, Journey, Ram",
    "Chrysler": "300C, Caravan, PT Cruiser, Town & Country",
    "Alfa Romeo": "145, 155, 156, 164",
    "Seat": "Cordoba, Ibiza",
    "Lada": "Laika, Niva, Samara",
    "Daewoo": "Espero, Lanos, Leganza, Nubira",
    "SsangYong": "Actyon, Korando, Kyron, Rexton",
    "Troller": "T4",
    "Agrale": "Marruá",
}


def cadastrar_modelos(apps, schema_editor):
    Modelo = apps.get_model("veiculos", "ModeloVeiculo")
    Veiculo = apps.get_model("veiculos", "Veiculo")
    banco = schema_editor.connection.alias
    for marca, modelos in CATALOGO.items():
        for nome in modelos.split(", "):
            Modelo.objects.using(banco).get_or_create(marca=marca, nome=nome)
    for marca, nome in Veiculo.objects.using(banco).values_list("marca", "modelo").distinct():
        Modelo.objects.using(banco).get_or_create(marca=marca, nome=nome)


class Migration(migrations.Migration):
    dependencies = [("veiculos", "0002_modeloveiculo")]
    operations = [migrations.RunPython(cadastrar_modelos, migrations.RunPython.noop)]
