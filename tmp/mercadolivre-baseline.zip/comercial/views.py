import uuid
from decimal import Decimal
from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.core.exceptions import ValidationError
from django.db import transaction
from django.core.paginator import Paginator
from django.db.models import Sum, Value, DecimalField, F, Q
from django.db.models.functions import Coalesce
from django.http import HttpResponse, Http404
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from .models import Servico, Documento, ContaReceber
from .forms import ServicoForm, DocumentoForm, ItensFormSet, ContaForm, PlanoReceberForm
from .services import converter, receber, registrar_venda_os, criar_conta_receber, salvar_plano_receber
from vendas.forms import CheckoutForm, PagamentosFormSet, ReceberNotaForm
from vendas.views import dados_promissoria


@login_required
@permission_required('comercial.view_servico',raise_exception=True)
def servicos(request):
    q = request.GET.get('q','')[:160]
    return render(request,'comercial/servicos.html',{'servicos':Servico.objects.filter(nome__icontains=q),'q':q})


@login_required
def servico_editar(request,pk=None):
    from caixa.services import exigir
    exigir(request.user,'comercial.change_servico' if pk else 'comercial.add_servico')
    instance = get_object_or_404(Servico,pk=pk) if pk else None
    form = ServicoForm(request.POST if request.method == "POST" else None,instance=instance)
    if request.method == 'POST' and form.is_valid():
        form.save()
        return redirect('comercial:servicos')
    return render(request,'comercial/servico_form.html',{'form':form})


@login_required
@permission_required('comercial.view_documento',raise_exception=True)
def documentos(request,tipo):
    if tipo not in ['orcamento','os']: raise Http404
    qs = (
    Documento.objects
    .filter(tipo=tipo)
    .select_related('cliente', 'venda')
    .prefetch_related('contareceber_set'))
    status = request.GET.get('status','')
    if status: qs = qs.filter(status=status)
    q = request.GET.get('q','')[:160]
    if q: qs = qs.filter(cliente__nome__icontains=q)
    return render(request,'comercial/lista.html',{'pagina':Paginator(qs,30).get_page(request.GET.get('page')),'tipo':tipo,'titulo':'Orçamentos' if tipo=='orcamento' else 'Ordens de serviço','q':q,'status':status,'estados':Documento.STATUS})


@login_required
@transaction.atomic
def documento_editar(request,tipo=None,pk=None):
    from caixa.services import exigir
    exigir(request.user,'comercial.change_documento' if pk else 'comercial.add_documento')
    doc = get_object_or_404(Documento.objects.select_for_update(),pk=pk) if pk else Documento(tipo=tipo,criado_por=request.user,status='rascunho' if tipo=='orcamento' else 'aberta')
    if doc.tipo not in ['orcamento','os']: raise Http404
    if doc.status == 'convertido':
        messages.error(request,'Documento convertido não pode ser editado.')
        return redirect('comercial:detalhe',pk=doc.pk)
    form = DocumentoForm(request.POST if request.method == "POST" else None,instance=doc)
    financeiro_fechado = bool(doc.venda_id)
    if financeiro_fechado:
        for campo in ['cliente', 'desconto', 'forma_pagamento', 'condicao_pagamento', 'parcelas', 'primeiro_vencimento']:
            form.fields[campo].disabled = True
        if doc.venda.status == 'cancelada':
            form.fields['status'].disabled = True
    itens = ItensFormSet(request.POST if request.method == "POST" and not financeiro_fechado else None,instance=doc,prefix='itens')
    if financeiro_fechado:
        for item in itens:
            for campo in item.fields.values():
                campo.disabled = True
    if request.method == 'POST':
        valido = form.is_valid()
        if valido and (financeiro_fechado or itens.is_valid()):
            try:
                with transaction.atomic():
                    novo = doc.pk is None
                    if novo and doc.tipo == 'os' and doc.status == 'cancelada':
                        raise ValidationError('Crie a ordem com uma situação ativa.')
                    form.save()
                    if not financeiro_fechado:
                        itens.save()
                    if novo and doc.tipo == 'os':
                        registrar_venda_os(request.user, doc.pk)
                    elif financeiro_fechado and doc.status == 'cancelada':
                        from vendas.services import cancelar
                        cancelar(request.user, doc.venda_id, f'Cancelamento pela OS {doc.codigo}')
                return redirect('comercial:detalhe',pk=doc.pk)
            except ValidationError as exc:
                form.add_error(None, exc)
                if not pk:
                    doc.pk = None
                    doc._state.adding = True
    from estoque.models import Peca
    return render(request,'comercial/editar.html',{'form':form,'itens':itens,'doc':doc,'financeiro_fechado':financeiro_fechado,'precos':{'peca':{str(p.pk):str(p.preco_venda) for p in Peca.objects.all()},'servico':{str(s.pk):str(s.valor_padrao) for s in Servico.objects.all()}}})



@login_required
@permission_required('comercial.delete_documento', raise_exception=True)
@transaction.atomic
def orcamento_excluir(request, pk):
    doc = get_object_or_404(Documento.objects.select_for_update(), pk=pk)

    if doc.tipo != 'orcamento':
        raise Http404

    convertido = (
        doc.status == 'convertido'
        or doc.venda_id
        or Documento.objects.filter(origem=doc).exists()
    )

    if convertido:
        messages.error(request, 'Orçamento convertido não pode ser excluído.')
        return redirect('comercial:detalhe', pk=doc.pk)

    if request.method != 'POST':
        return redirect('comercial:detalhe', pk=doc.pk)

    codigo = doc.codigo
    doc.delete()
    messages.success(request, f'Orçamento {codigo} excluído com sucesso.')
    return redirect('comercial:documentos', tipo='orcamento')

@login_required
@permission_required('comercial.view_documento',raise_exception=True)
def detalhe(request,pk):
    doc = get_object_or_404(Documento.objects.select_related('cliente','venda','origem').prefetch_related('itens'),pk=pk)
    return render(request,'comercial/detalhe.html',{'doc':doc,'ordem':Documento.objects.filter(origem=doc).first()})


@login_required
@permission_required('comercial.converter_documento',raise_exception=True)
def conversao(request,pk,destino):
    if destino not in ['venda','os']: raise Http404
    doc = get_object_or_404(Documento,pk=pk)
    form = CheckoutForm(request.POST if request.method == "POST" else None,initial={'chave':uuid.uuid4(),'cliente':doc.cliente_id,'desconto':doc.desconto})
    pagamentos = PagamentosFormSet(request.POST if request.method == "POST" else None,prefix='pag')
    if request.method == 'POST':
        try:
            if request.POST.get('confirmar') != 'sim':
                raise ValidationError('Marque a confirmação para converter.')
            if destino == 'os':
                novo = converter(request.user,pk,destino,True)
                return redirect('comercial:detalhe',pk=novo.pk)
            if form.is_valid() and (form.cleaned_data['a_prazo'] or pagamentos.is_valid()):
                valores = [] if form.cleaned_data['a_prazo'] else [{'forma':f.cleaned_data['forma'].pk,'valor':f.cleaned_data['valor']} for f in pagamentos if f.cleaned_data]
                novo = converter(request.user,pk,destino,True,pagamentos=valores,vencimento=form.cleaned_data['vencimento_conta'] if form.cleaned_data['a_prazo'] else None,dados_nota=dados_promissoria(form))
                return redirect('vendas:detalhe',pk=novo.pk)
        except ValidationError as e:
            form.add_error(None,e)
    return render(request,'comercial/converter.html',{'doc':doc,'destino':destino,'form':form,'pagamentos':pagamentos})


@login_required
@permission_required('comercial.view_documento',raise_exception=True)
def imprimir(request,pk,formato):
    from .pdf import gerar_pdf
    if formato not in ['a4','58']: raise Http404
    doc = get_object_or_404(Documento.objects.select_related('cliente').prefetch_related('itens'),pk=pk)
    response = HttpResponse(gerar_pdf(doc,termico=formato=='58'),content_type='application/pdf')
    response['Content-Disposition'] = f'inline; filename="{doc.codigo}-{formato}.pdf"'
    response['Cache-Control'] = 'private, no-store'
    return response


@login_required
@permission_required('comercial.view_contareceber',raise_exception=True)
def contas(request):
    from .financeiro_consultas import contexto_promissorias
    hoje = timezone.localdate()
    qs = ContaReceber.objects.select_related('cliente','venda','os').annotate(recebido=Coalesce(Sum('recebimentos__valor'),Value(Decimal('0')),output_field=DecimalField(max_digits=12,decimal_places=2)))
    q = request.GET.get('q', '').strip()[:240]
    if q:
        qs = qs.filter(Q(descricao__icontains=q) | Q(cliente__nome__icontains=q) | Q(cliente__documento__icontains=q) | Q(origem__icontains=q))
    status = request.GET.get('status','')
    if status == 'vencidas': qs=qs.filter(cancelada=False,vencimento__lt=hoje,recebido__lt=F('valor_original'))
    elif status == 'vencer': qs=qs.filter(cancelada=False,vencimento__gte=hoje,recebido__lt=F('valor_original'))
    elif status == 'recebidas': qs=qs.filter(cancelada=False,recebido=F('valor_original'))
    elif status == 'parciais': qs=qs.filter(cancelada=False,recebido__gt=0,recebido__lt=F('valor_original'))
    elif status == 'canceladas': qs=qs.filter(cancelada=True)
    from datetime import date
    for key,lookup in [('inicio','vencimento__gte'),('fim','vencimento__lte')]:
        try:
            if request.GET.get(key): qs=qs.filter(**{lookup:date.fromisoformat(request.GET[key])})
        except ValueError: messages.error(request,'Data inválida no filtro.')
    resumo = qs.aggregate(recebidos=Sum('recebido'), total=Sum('valor_original'))
    abertas = qs.filter(cancelada=False, recebido__lt=F('valor_original'))
    saldo = F('valor_original') - F('recebido')
    parametros = request.GET.copy()
    parametros.pop('page', None)
    return render(request,'comercial/contas.html',{'pagina':Paginator(qs.order_by('vencimento','pk').prefetch_related('recebimentos', 'parcelas_financeiras__forma_prevista'),30).get_page(request.GET.get('page')),
        'status':status, 'q':q, 'recebidos':resumo['recebidos'] or 0, 'total_filtrado':resumo['total'] or 0,
        'pendente':abertas.aggregate(s=Sum(saldo))['s'] or 0,
        'atrasado':abertas.filter(vencimento__lt=hoje).aggregate(s=Sum(saldo))['s'] or 0,
        'parametros':parametros.urlencode(), **contexto_promissorias(request.user,request.GET)})


@login_required
@permission_required('comercial.add_contareceber',raise_exception=True)
def conta_nova(request):
    form = ContaForm(request.POST if request.method == "POST" else None)
    if request.method=='POST' and form.is_valid():
        try:
            conta=criar_conta_receber(request.user, form.cleaned_data)
            return redirect('comercial:conta',pk=conta.pk)
        except ValidationError as exc:
            form.add_error(None, exc)
    return render(request,'comercial/conta_formulario.html',{'form':form,'titulo':'Nova conta a receber'})


@login_required
@permission_required('comercial.view_contareceber',raise_exception=True)
def conta(request,pk):
    conta=get_object_or_404(ContaReceber.objects.select_related('cliente','venda','os').prefetch_related('recebimentos__operador','parcelas_financeiras__forma_prevista'),pk=pk)
    form=ReceberNotaForm(request.POST if request.method == "POST" else None,initial={'chave':uuid.uuid4(),'valor':conta.saldo})
    if request.method=='POST' and form.is_valid():
        try:
            receber(request.user,pk,form.cleaned_data['valor'],form.cleaned_data['forma'].pk,form.cleaned_data['chave'])
            return redirect('comercial:conta',pk=pk)
        except ValidationError as e: form.add_error(None,e)
    return render(request,'comercial/conta.html',{'conta':conta,'form':form})


@login_required
@permission_required('comercial.change_contareceber',raise_exception=True)
@transaction.atomic
def conta_cancelar(request,pk):
    from django.views.decorators.http import require_POST
    if request.method!='POST': return HttpResponse(status=405)
    conta=get_object_or_404(ContaReceber.objects.select_for_update(),pk=pk)
    if conta.venda_id or conta.valor_recebido:
        messages.error(request,'Conta vinculada Ã  venda ou com recebimentos: preserve o histórico. Para venda sem recebimentos, use o cancelamento da venda.')
    elif request.POST.get('confirmar')=='sim':
        conta.cancelada=True
        conta.save(update_fields=['cancelada'])
    return redirect('comercial:conta',pk=pk)
